Projet Groupe

# PYTHON ANALYSE DE DONNEES POUR UNE IA
IPSSI Paris - [PRS] MIA4 26.2


________________________________________________________
COODIEN Govindarajen (Arbre de Décision/Rédaction)

BAKAYOKO Moussa (Réseau de Neurones)

TCHINDA D. Stevie C. (Clusteing)
